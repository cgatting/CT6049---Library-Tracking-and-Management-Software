SELECT table_name FROM user_tables;
SELECT COUNT(*) AS student_count FROM Students;
SELECT COUNT(*) AS book_count FROM Books;
SELECT COUNT(*) AS loan_count FROM Loans;
SELECT COUNT(*) AS fine_count FROM Fines;
EXIT;