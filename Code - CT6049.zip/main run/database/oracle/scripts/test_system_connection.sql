SELECT 'SYSTEM connection successful!' FROM dual;
EXIT;