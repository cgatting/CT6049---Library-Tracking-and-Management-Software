SELECT 'Library user connection successful!' FROM dual;
EXIT;