SELECT 'Connected as SYSDBA!' FROM dual;
EXIT;