/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc;

import java.io.Serializable;

public interface LogicalTransactionId
extends Serializable {
}

