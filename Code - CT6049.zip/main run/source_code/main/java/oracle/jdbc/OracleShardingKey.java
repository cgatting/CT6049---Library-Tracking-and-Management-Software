/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc;

public interface OracleShardingKey
extends Comparable<OracleShardingKey> {
}

