/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc;

import java.sql.NClob;
import oracle.jdbc.OracleClob;

public interface OracleNClob
extends NClob,
OracleClob {
}

