/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

import oracle.jdbc.driver.BinaryDoubleBinder;

class BinaryDoubleCopyingBinder
extends BinaryDoubleBinder {
    BinaryDoubleCopyingBinder(double d2) {
        super(d2);
    }
}

