/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

import oracle.jdbc.driver.RefCursorBinder;

class RefCursorCopyingBinder
extends RefCursorBinder {
    RefCursorCopyingBinder(int n2) {
        super(n2);
    }
}

