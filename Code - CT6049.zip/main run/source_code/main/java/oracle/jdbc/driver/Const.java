/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

public class Const
extends oracle.jdbc.Const {
}

