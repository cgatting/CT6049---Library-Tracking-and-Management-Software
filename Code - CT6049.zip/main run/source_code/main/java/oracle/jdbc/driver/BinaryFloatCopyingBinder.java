/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

import oracle.jdbc.driver.BinaryFloatBinder;

class BinaryFloatCopyingBinder
extends BinaryFloatBinder {
    BinaryFloatCopyingBinder(float f2) {
        super(f2);
    }
}

