/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

import oracle.jdbc.driver.PlsqlIbtBinder;

class PlsqlIbtCopyingBinder
extends PlsqlIbtBinder {
    PlsqlIbtCopyingBinder() {
        PlsqlIbtBinder.init(this);
    }
}

