/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

class OracleTypes
extends oracle.jdbc.internal.OracleTypes {
    OracleTypes() {
    }
}

