/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.driver;

public interface Message {
    public String msg(String var1, Object var2);
}

