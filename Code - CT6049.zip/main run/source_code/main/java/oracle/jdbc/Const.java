/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc;

public class Const {
    public static final short NCHAR = 2;
    public static final short CHAR = 1;
}

