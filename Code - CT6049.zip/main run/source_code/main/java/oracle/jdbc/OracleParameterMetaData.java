/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc;

import java.sql.ParameterMetaData;

public interface OracleParameterMetaData
extends ParameterMetaData {
}

