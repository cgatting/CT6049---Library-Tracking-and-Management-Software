/*
 * Decompiled with CFR 0.152.
 */
package oracle.jdbc.datasource;

import javax.sql.XAConnection;
import oracle.jdbc.datasource.OraclePooledConnection;

public interface OracleXAConnection
extends XAConnection,
OraclePooledConnection {
}

