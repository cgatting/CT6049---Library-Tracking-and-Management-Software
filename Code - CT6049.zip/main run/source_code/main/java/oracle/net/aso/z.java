/*
 * Decompiled with CFR 0.152.
 */
package oracle.net.aso;

interface z {
    public void b(byte[] var1, byte[] var2);

    public byte[] g(byte[] var1);

    public byte[] f(byte[] var1);

    public int a(byte[] var1, int var2, int var3, byte[] var4);

    public int b(byte[] var1, int var2, int var3, byte[] var4);

    public boolean j(int var1);

    public String getProviderName();
}

