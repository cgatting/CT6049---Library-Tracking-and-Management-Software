/*
 * Decompiled with CFR 0.152.
 */
package oracle.net.aso;

interface ag {
    public void a(int var1, byte[] var2, int var3);

    public void a(byte[] var1, byte[] var2, int var3);

    public String getProviderName();
}

