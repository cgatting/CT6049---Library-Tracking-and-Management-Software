/*
 * Decompiled with CFR 0.152.
 */
package oracle.net.aso;

import oracle.net.aso.h;
import oracle.net.aso.z;

final class x
implements h {
    private final z aK;

    x(z z2) {
        this.aK = z2;
    }

    @Override
    public final byte[] g(byte[] byArray) {
        return this.aK.g(byArray);
    }

    @Override
    public final byte[] f(byte[] byArray) {
        return this.aK.f(byArray);
    }

    @Override
    public final void j(byte[] byArray) {
    }
}

